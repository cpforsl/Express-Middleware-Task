import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import { connectDb } from "./src/config/db.js";
import authRouter from "./src/routes/auth.js";
import todosRouter from "./src/routes/todos.js";
import { enforceJson } from "./src/middleware/enforceJson.js";

dotenv.config();

const app = express();

// CORS for the React client
app.use(
  cors({
    origin: process.env.CLIENT_ORIGIN || "http://localhost:5173",
    credentials: true
  })
);

// Parse JSON body
app.use(express.json());

// Reject non-JSON requests that carry a body (requirement)
app.use(enforceJson);

// Routes
app.use("/api/auth", authRouter);
app.use("/api/todos", todosRouter);

const PORT = process.env.PORT || 8080;

connectDb().then(() => {
  app.listen(PORT, () => {
    console.log(`API listening on http://localhost:${PORT}`);
  });
});
