import { Router } from "express";
import Todo from "../models/Todo.js";
import { authenticate } from "../middleware/authenticate.js";
import { enforceGmail } from "../middleware/enforceGmail.js";
import { limitTaskLength } from "../middleware/limitTaskLength.js";

const router = Router();

// All todo endpoints require auth and gmail policy
router.use(authenticate, enforceGmail);

// Read all
router.get("/", async (req, res) => {
  const todos = await Todo.find({ userId: req.user.id }).sort({ createdAt: -1 });
  res.json(todos);
});

// Create
router.post("/", limitTaskLength, async (req, res) => {
  const { text } = req.body || {};
  if (!text || !text.trim()) return res.status(400).json({ error: "Text is required" });

  const todo = await Todo.create({ userId: req.user.id, text: text.trim() });
  res.status(201).json(todo);
});

// Update
router.put("/:id", limitTaskLength, async (req, res) => {
  const { id } = req.params;
  const { text, done } = req.body || {};

  const update = {};
  if (typeof text === "string") update.text = text.trim();
  if (typeof done === "boolean") update.done = done;

  const todo = await Todo.findOneAndUpdate(
    { _id: id, userId: req.user.id },
    { $set: update },
    { new: true }
  );
  if (!todo) return res.status(404).json({ error: "Not found" });
  res.json(todo);
});

// Delete
router.delete("/:id", async (req, res) => {
  const { id } = req.params;
  const result = await Todo.deleteOne({ _id: id, userId: req.user.id });
  if (!result.deletedCount) return res.status(404).json({ error: "Not found" });
  res.status(204).end();
});

export default router;
