// Reject creation/update when text exceeds 140 chars.
export function limitTaskLength(req, res, next) {
  const { text } = req.body || {};
  if (typeof text === "string" && text.length > 140) {
    return res.status(400).json({ error: "Task text exceeds 140 characters" });
  }
  next();
}
