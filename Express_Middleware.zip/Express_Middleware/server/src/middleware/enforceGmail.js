// 403 for any request by users whose usernames don't end with '@gmail.com'.
// For unauthenticated routes (register/login), we check req.body.email.
// For authenticated routes, we check req.user.email set by authenticate.
export function enforceGmail(req, res, next) {
  const email =
    (req.user && req.user.email) ||
    (req.body && req.body.email) ||
    (req.query && req.query.email);

  if (!email || !email.toLowerCase().endsWith("@gmail.com")) {
    return res.status(403).json({ error: "Access restricted to @gmail.com accounts" });
  }
  next();
}
