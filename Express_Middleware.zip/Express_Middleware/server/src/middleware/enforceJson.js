// Reject any requests that are not JSON when they include a body.
// Safe to allow GET/HEAD without Content-Type.
export function enforceJson(req, res, next) {
  const methodsWithBody = ["POST", "PUT", "PATCH", "DELETE"];
  if (!methodsWithBody.includes(req.method)) return next();

  const ct = req.headers["content-type"] || "";
  if (!ct.toLowerCase().startsWith("application/json")) {
    return res.status(415).json({ error: "Content-Type must be application/json" });
  }
  next();
}
