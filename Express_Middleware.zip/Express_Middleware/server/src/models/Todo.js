import mongoose from "mongoose";

const todoSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", index: true },
    text: { type: String, required: true, maxlength: 140 },
    done: { type: Boolean, default: false }
  },
  { timestamps: true }
);

export default mongoose.model("Todo", todoSchema);
