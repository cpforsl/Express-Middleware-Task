import React from "react";
import { useAuth } from "../context/AuthContext.jsx";

export default function NavBar() {
  const { user, logout } = useAuth();
  return (
    <header style={{ padding: 12, borderBottom: "1px solid #eee", display: "flex", justifyContent: "space-between" }}>
      <strong>Express Middleware Task</strong>
      {user ? (
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <span>{user.email}</span>
          <button onClick={logout}>Logout</button>
        </div>
      ) : null}
    </header>
  );
}
