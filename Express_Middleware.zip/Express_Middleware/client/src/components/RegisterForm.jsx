import React from "react";
import { makeClient } from "../lib/api.js";

export default function RegisterForm() {
  const client = React.useMemo(() => makeClient(() => ""), []);
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [ok, setOk] = React.useState("");
  const [err, setErr] = React.useState("");

  async function onSubmit(e) {
    e.preventDefault();
    setErr(""); setOk("");
    try {
      await client.register(email, password);
      setOk("Registered. You can now log in.");
    } catch (e2) {
      setErr(e2.message);
    }
  }

  return (
    <form onSubmit={onSubmit}>
      <div style={{ display: "grid", gap: 8 }}>
        <input placeholder="email@gmail.com" value={email} onChange={e => setEmail(e.target.value)} />
        <input placeholder="password" type="password" value={password} onChange={e => setPassword(e.target.value)} />
        <button type="submit">Create Account</button>
        {ok && <div style={{ color: "seagreen" }}>{ok}</div>}
        {err && <div style={{ color: "crimson" }}>{err}</div>}
      </div>
    </form>
  );
}
