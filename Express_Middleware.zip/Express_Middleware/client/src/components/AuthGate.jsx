import React from "react";
import { useAuth } from "../context/AuthContext.jsx";
import LoginForm from "./LoginForm.jsx";
import RegisterForm from "./RegisterForm.jsx";

export default function AuthGate() {
  const { user } = useAuth();
  const [mode, setMode] = React.useState("login");

  if (user) return null;

  return (
    <div style={{ maxWidth: 420, margin: "40px auto", padding: 16 }}>
      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <button onClick={() => setMode("login")} disabled={mode === "login"}>Login</button>
        <button onClick={() => setMode("register")} disabled={mode === "register"}>Register</button>
      </div>
      {mode === "login" ? <LoginForm /> : <RegisterForm />}
      <p style={{ marginTop: 10, fontSize: 12, opacity: 0.7 }}>
        Only @gmail.com addresses are allowed.
      </p>
    </div>
  );
}
