import React from "react";

export default function TodoEditor({ onAdd }) {
  const [text, setText] = React.useState("");
  const [err, setErr] = React.useState("");

  function remaining() {
    return 140 - (text?.length || 0);
  }

  async function submit(e) {
    e.preventDefault();
    setErr("");
    try {
      await onAdd(text);
      setText("");
    } catch (e2) {
      setErr(e2.message);
    }
  }

  return (
    <form onSubmit={submit} style={{ display: "grid", gap: 8 }}>
      <textarea
        rows={3}
        value={text}
        onChange={e => setText(e.target.value)}
        placeholder="Add a task (≤ 140 chars)"
      />
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <span style={{ fontSize: 12, opacity: 0.7 }}>{remaining()} characters left</span>
        <button type="submit" disabled={!text.trim() || text.length > 140}>Add</button>
      </div>
      {err && <div style={{ color: "crimson" }}>{err}</div>}
    </form>
  );
}
