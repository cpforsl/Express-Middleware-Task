import React from "react";
import { useAuth } from "../context/AuthContext.jsx";
import { makeClient } from "../lib/api.js";

export default function LoginForm() {
  const { login } = useAuth();
  const client = React.useMemo(() => makeClient(() => ""), []);
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [err, setErr] = React.useState("");

  async function onSubmit(e) {
    e.preventDefault();
    setErr("");
    try {
      const data = await client.login(email, password);
      login(data);
    } catch (e2) {
      setErr(e2.message);
    }
  }

  return (
    <form onSubmit={onSubmit}>
      <div style={{ display: "grid", gap: 8 }}>
        <input placeholder="email@gmail.com" value={email} onChange={e => setEmail(e.target.value)} />
        <input placeholder="password" type="password" value={password} onChange={e => setPassword(e.target.value)} />
        <button type="submit">Login</button>
        {err && <div style={{ color: "crimson" }}>{err}</div>}
      </div>
    </form>
  );
}
