import React from "react";

export default function TodoList({ todos, onToggle, onUpdateText, onDelete }) {
  return (
    <ul style={{ listStyle: "none", padding: 0, display: "grid", gap: 8 }}>
      {todos.map(t => (
        <li key={t._id} style={{ border: "1px solid #ddd", padding: 8, borderRadius: 6 }}>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <input type="checkbox" checked={!!t.done} onChange={() => onToggle(t)} />
            <input
              value={t.text}
              onChange={e => onUpdateText(t, e.target.value)}
              style={{ flex: 1 }}
            />
            <button onClick={() => onDelete(t)}>Delete</button>
          </div>
          <div style={{ fontSize: 12, opacity: 0.6 }}>
            {new Date(t.createdAt).toLocaleString()}
          </div>
        </li>
      ))}
    </ul>
  );
}
