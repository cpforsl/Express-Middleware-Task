import React from "react";
import { AuthProvider, useAuth } from "./context/AuthContext.jsx";
import { makeClient } from "./lib/api.js";
import AuthGate from "./components/AuthGate.jsx";
import TodoEditor from "./components/TodoEditor.jsx";
import TodoList from "./components/TodoList.jsx";
import NavBar from "./components/NavBar.jsx";

function AppShell() {
  const { token } = useAuth();
  const api = React.useMemo(() => makeClient(() => token), [token]);
  const [todos, setTodos] = React.useState([]);
  const [err, setErr] = React.useState("");

  React.useEffect(() => {
    let ignore = false;
    if (!token) return;
    api.listTodos()
      .then(data => { if (!ignore) setTodos(data); })
      .catch(e => setErr(e.message));
    return () => { ignore = true; };
  }, [token]);

  async function addTodo(text) {
    const created = await api.addTodo(text);
    setTodos(prev => [created, ...prev]);
  }

  async function toggleTodo(todo) {
    const updated = await api.updateTodo(todo._id, { done: !todo.done });
    setTodos(prev => prev.map(t => (t._id === updated._id ? updated : t)));
  }

  async function updateText(todo, text) {
    try {
      const updated = await api.updateTodo(todo._id, { text });
      setTodos(prev => prev.map(t => (t._id === updated._id ? updated : t)));
    } catch (e) {
      setErr(e.message);
    }
  }

  async function deleteTodo(todo) {
    await api.deleteTodo(todo._id);
    setTodos(prev => prev.filter(t => t._id !== todo._id));
  }

  return (
    <div>
      <NavBar />
      {!token ? (
        <AuthGate />
      ) : (
        <div style={{ maxWidth: 720, margin: "24px auto", padding: 12 }}>
          <TodoEditor onAdd={addTodo} />
          {err && <div style={{ color: "crimson", marginTop: 8 }}>{err}</div>}
          <TodoList
            todos={todos}
            onToggle={toggleTodo}
            onUpdateText={updateText}
            onDelete={deleteTodo}
          />
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppShell />
    </AuthProvider>
  );
}
